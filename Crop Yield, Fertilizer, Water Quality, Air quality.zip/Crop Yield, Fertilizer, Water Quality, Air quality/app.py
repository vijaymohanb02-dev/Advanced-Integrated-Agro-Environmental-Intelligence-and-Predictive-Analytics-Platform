from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.model_selection import train_test_split
import os

app = Flask(__name__)
app.secret_key = 'super_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

# ------------------ DATABASE ------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)


# =====================================================
# ================= AQI MODEL =========================
# =====================================================

MODEL_FILE = 'tree_gridcv.joblib'
DATA_FILE = 'air_quality_data.csv'

if os.path.exists(MODEL_FILE):
    model = joblib.load(MODEL_FILE)
else:
    if not os.path.exists(DATA_FILE):
        df = pd.DataFrame({
            'T': np.random.uniform(10, 40, 100),
            'TM': np.random.uniform(10, 40, 100),
            'Tm': np.random.uniform(10, 40, 100),
            'SLP': np.random.uniform(900, 1050, 100),
            'H': np.random.uniform(20, 100, 100),
            'VV': np.random.uniform(0, 10, 100),
            'V': np.random.uniform(0, 20, 100),
            'VM': np.random.uniform(0, 20, 100),
            'AQI': np.random.uniform(50, 200, 100)
        })
        df.to_csv(DATA_FILE, index=False)
    else:
        df = pd.read_csv(DATA_FILE)

    X = df[['T', 'TM', 'Tm', 'SLP', 'H', 'VV', 'V', 'VM']]
    y = df['AQI']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = ExtraTreesRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    joblib.dump(model, MODEL_FILE)


# =====================================================
# ================= AUTH ROUTES =======================
# =====================================================

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = generate_password_hash(request.form['password'])

        if User.query.filter_by(email=email).first():
            return "User already exists."

        user = User(email=email, password=password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            session['user'] = user.email
            return redirect(url_for('dashboard'))

        return "Invalid credentials"

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))


# =====================================================
# ================= DASHBOARD =========================
# =====================================================

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/about')
def about():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('about.html')
# =====================================================
# ================= AQI PREDICTION ====================
# =====================================================

@app.route('/aqi', methods=['GET', 'POST'])
def aqi():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        try:
            print("FORM DATA:", request.form)

            input_features = [
                float(request.form.get("T")),
                float(request.form.get("TM")),
                float(request.form.get("Tm")),
                float(request.form.get("SLP")),
                float(request.form.get("H")),
                float(request.form.get("VV")),
                float(request.form.get("V")),
                float(request.form.get("VM"))
            ]

            print("INPUT FEATURES:", input_features)

            input_array = np.array(input_features).reshape(1, -1)
            print("INPUT SHAPE:", input_array.shape)

            prediction = model.predict(input_array)[0]
            print("PREDICTION:", prediction)

            return render_template(
                'result.html',
                prediction=f"Predicted AQI: {round(prediction,2)}"
            )

        except Exception as e:
            print("ERROR OCCURRED:", e)
            return f"REAL ERROR: {str(e)}"

    return render_template('aqi.html')



# =====================================================
# ================= CROP YIELD ========================
# =====================================================

@app.route('/crop_yield', methods=['GET', 'POST'])
def crop_yield():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        try:
            area = float(request.form['Area'])
            production = float(request.form['Production'])
            annual_rainfall = float(request.form['Annual_Rainfall'])
            fertilizer = float(request.form['Fertilizer'])
            pesticide = float(request.form['Pesticide'])

            base_yield = production / area
            adjusted_yield = base_yield * (1 + (annual_rainfall/1000)*0.1 + (fertilizer/200)*0.2 + (pesticide/100)*0.1)

            return render_template('result1.html',
                                   prediction=f"Estimated Yield: {round(adjusted_yield,2)} tons/hectare")

        except:
            return "Error in input."

    return render_template('crop_yield.html')


# =====================================================
# ================= FERTILIZER ========================
# =====================================================

@app.route('/fertilizer', methods=['GET', 'POST'])
def fertilizer():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        nitrogen = float(request.form['nitrogen'])
        phosphorous = float(request.form['phosphorous'])
        potassium = float(request.form['potassium'])

        recommendation = "Balanced Fertilizer (20-20-20)"

        if nitrogen < 50:
            recommendation = "Urea"
        elif phosphorous < 30:
            recommendation = "DAP"
        elif potassium < 30:
            recommendation = "Potash"

        return render_template('result2.html',
                               prediction=f"Recommended Fertilizer: {recommendation}")

    return render_template('fertilizer.html')


# =====================================================
# ================= WATER QUALITY =====================
# =====================================================

@app.route('/water_quality', methods=['GET', 'POST'])
def water_quality():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        ph = float(request.form['pH'])

        if 6.5 <= ph <= 8.5:
            result = "Good Water Quality"
        else:
            result = "Unsafe Water"

        return render_template('result3.html', prediction=result)

    return render_template('water_quality.html')


# =====================================================

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
